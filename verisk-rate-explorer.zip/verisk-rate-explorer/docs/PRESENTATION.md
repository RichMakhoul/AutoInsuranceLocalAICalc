# Presentation notes

Prep for presenting Auto Rate Explorer. Read the opener and the Q&A; the rest is a
safety net.

**Every dollar figure below is verified against the live API.** If you change the
rating tables, re-verify before presenting.

---

## Before you start

```bash
cd ~/Desktop/verisk-rate-explorer && ./run.sh
```

Open **http://localhost:5000**, and before the call:

- Run one quote end to end so the model is warm — the first LLM call loads ~2GB into
  RAM and takes ~5s; every call after is 2–3s. Don't let them watch the cold start.
- Have a second tab on `backend/rating.py` for the code portion.
- If wifi is unreliable: everything works offline **except map tiles**. The premiums,
  the LLM, the county resolution all still run. Say so if tiles fail — it's a good
  moment, not a bad one.

---

## The opener (about 45 seconds)

> "Verisk sits behind a lot of personal auto rating, so I built something in that
> space: enter a car and a city, and it rates that same risk across every county in
> the state.
>
> The obvious way to build this is to ask an LLM what insurance costs. I deliberately
> didn't, because auto is a filed and regulated line — a regulator can ask why an
> insured was charged a given amount, and 'the model said so' isn't an answer.
>
> So I split it. A deterministic rating engine produces every dollar figure. The
> language model does two things it's actually good at: parsing messy input, and
> explaining the result in English. It never touches a premium."

Then demo. Don't explain further first — show it.

---

## Demo path (about 3 minutes)

**1. Messy input → structured.**
Type `06 honda civic` in the Vehicle box, hit **Parse**.
> "That's llama3.2 running locally on my laptop. No API, no key, no data leaving the
> machine — which matters if the input is ever a real policyholder's."

*(If you want the better version, type `my beat up 98 corolla` — it infers Toyota from
the model name alone. Regex can't do that, and regex is the fallback.)*

**2. City → county, offline.**
Type `Lod`, pick **Lodi, NJ → Bergen County**.
> "Resolved by point-in-polygon against real county boundaries, precomputed. No
> geocoding service to rate-limit me or go down mid-demo."

**3. Rate it.** Click **Rate across the state**.
> "Same driver, same car, every county in New Jersey. Only territory changes.
> **$1,366 in Salem, $2,659 in Hudson** — a **95% spread** inside one state."

**4. The factor chain** (point at the left panel).
> "This is the whole plan, and it's multiplicative — the same shape a filed plan uses.
> **New Jersey base rate $1,693**, times territory, times vehicle, times driver age,
> times coverage. Every row is a number you can check."

**5. The grounded explanation.** Click **Explain this rate**, then expand
**"Show the exact facts the model was given."**
> "This is the part I most want to show you. The model is handed the already-computed
> factors and told to use only those numbers. Here's exactly what it received. It's
> narrating arithmetic, not doing it."

**6. The money shot.** Change to `2024 BMW M3`, driver age `19`, city `Jersey City`.
> "**$8,905.** Luxury tier, sports body, new vehicle, teenage driver, densest county in
> the state — the factors compound. That's what a rating plan is."

Chain for that one, if they ask you to walk it:
`1,693 × 1.335 (Hudson) × 1.38 (luxury) × 1.34 (sports) × 1.08 (2yr) × 1.973 (age 19)`

---

## The two technical points to land

**1. Premium neutrality.** If you say nothing else about the engine, say this:

> "Territory relativities are normalized so the population-weighted mean inside a
> state is exactly 1.0. That means redistributing premium across counties doesn't
> change the statewide average — the plan is premium-neutral by construction, which
> is how filed territory plans work. It's asserted in the test suite."

**2. The base rates are real and sourced.**

> "The base rate is NAIC's combined average premium per insured vehicle — Table 5 of
> the 2023 Auto Insurance Database supplement. I didn't type those numbers in; a
> script parses the PDF, so the provenance is reproducible. The check is that my
> parsed countrywide figure reproduces NAIC's published $1,438.46 exactly."

Those two together are what separate this from a demo that multiplies made-up numbers.

---

## Questions they will ask

**"Where do the numbers come from?"**
> Three sources, all public. Population and land area for all 3,144 counties come from
> the Census — that drives territory. State base rates come from NAIC's 2023 Auto
> Insurance Database supplement, Table 5, parsed from the PDF by a script so it's
> reproducible. The vehicle and driver relativities are mine — they're structured like
> a real rating plan but they aren't empirically fit, and that's the part I'd replace
> first given access to real loss data.

**"How accurate is it?"**
> As a directional model of how premium varies geographically, good — the base is a real
> published average and the geography is real. As a quote, it isn't one and I don't
> present it as one. There's no driver history, no credit, no mileage, no VIN-level
> symbol, and each of those moves a real premium more than territory does.

**"NAIC's number is a market average, not a filed rate — doesn't that break the model?"**
> It's an approximation, and it's the one I'd call out myself. Table 5 already blends
> every driver age, vehicle and territory in the state. I'm layering relativities
> centered on 1.0 on top of a blended mean, so an average risk in an average county
> returns roughly the state average — which is coherent, but a real plan starts from a
> filed base rate for a defined base class, not from a market mean. That's limitation
> three in the README.

**"Why density for territory?"**
> Urban exposure drives claim frequency — more vehicles interacting per mile, more
> theft, more uninsured-motorist and litigation exposure. It's a proxy. A real plan
> rates territory on observed loss costs, and density correlates with several of those
> without substituting for any of them. It's the first thing I'd replace given real data.

**"Why a local model instead of GPT/Claude?"**
> Three reasons. Insurance input is personal data and this never leaves the machine.
> It costs nothing per call, so I could iterate freely. And it demos without wifi.
> The tradeoff is quality — a 3B model needs a much tighter prompt, which is why the
> system prompt spells out the causal direction of each factor. I had it telling people
> that density meant "higher demand for insurance," which is wrong, and that a county's
> rank *caused* its premium, which inverts cause and effect. I fixed both in the prompt
> rather than by post-processing the output.

**"What breaks at scale?"**
> Quotes are recomputed per request. It's pure arithmetic over at most 254 counties, so
> it's fast — territory relativities are cached per state and the county tables load
> once. The real scaling question isn't compute, it's that a production plan rates at
> ZIP or finer, which is ~40,000 territories instead of 3,144.

**"What would you do next?"**
Pick two, don't list six:
> ZIP-level territories instead of county, and real loss-cost data behind the territory
> factor instead of density. After that, VIN-level vehicle symbols.

**"Did you use AI to build this?"**
Answer honestly and specifically — the specifics land better than a vague answer. Know
these cold, because they're what you'd have to defend:
- the premium-neutrality normalization and why it matters
- why the LLM is walled off from the arithmetic
- the three data problems you hit: NJ townships aren't Census "places" (Montclair was
  missing), Connecticut replaced counties with planning regions in 2022 so it was absent
  from the boundary file entirely, and the CARTO basemap started demanding an API key
  and was stamping "API KEY REQUIRED" across the map

---

## If something breaks

| Symptom | Say | Do |
|---|---|---|
| Map tiles blank | "Tiles need network; the rating is all local." | Keep going — every number still works |
| LLM pill amber | "Model's down, so it fell back to the deterministic explanation — that fallback is why the app doesn't depend on it." | Keep going |
| Explain is slow | "CPU inference, ~3 seconds." | Let it finish, don't click twice |
| Port in use | — | `PORT=5050 ./run.sh` |

The fallbacks are a feature. If one fires during the demo, point at it deliberately
rather than apologizing.

---

## Don't

- Don't call it a quoting engine or say the numbers are real rates.
- Don't claim ISO data — say "the shape of a filed plan," not "ISO's plan."
- Don't oversell the LLM. Its job is small and deliberately so; that restraint *is*
  the design.
- Don't hide the limitations section. Opening it yourself is stronger than being
  walked into it.
